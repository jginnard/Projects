
public class Vertex {
	
	public Vertex(int[] array){
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
