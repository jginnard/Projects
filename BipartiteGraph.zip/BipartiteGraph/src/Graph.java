/*
 * Author: Jeremy Ginnard
 * Class: COSC 314
 * DATE: 29 NOV 2016
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Graph {
	private int size = 0;
	private int[][] array;
	Scanner in = new Scanner(System.in);
	
	ArrayList<Integer> partition1 = new ArrayList<Integer>();
	ArrayList<Integer> partition2 = new ArrayList<Integer>();
	ArrayList<Integer> neighbors1 = new ArrayList<Integer>();
	ArrayList<Integer> neighbors2 = new ArrayList<Integer>();
	
	/**
	 * Constructor for a Graph
	 * Prompts for the size of the set and each row of the matrix.
	 */
	public Graph(){
		System.out.print("Enter size of set: ");
		size = in.nextInt();
		array = new int[size][size];
		// Read in the matrix
		for(int i = 0; i<size; i++){
			System.out.print("Enter row " + i +": ");
			String row = in.next();
			for (int j = 0; j<size; j++){
				array[i][j] = row.charAt(j) == '0'? 0 : 1;
			}
		}
		System.out.println();
		printArray();
	}

	/**
	 * Determines whether the given matrix is bipartite.
	 * @return A string stating whether or not the graph is bipartite, 
	 * and the bi-partition if it is bipartite.
	 */
	public String isBipartite(){
		for(int i = 0; i < size; i++){
			if(checkNoNeighbors(i, neighbors1)){
				partition1.add(i);
				addNeighbors(i, neighbors1);
			} else if (checkNoNeighbors(i, neighbors2)){
				partition2.add(i);
				addNeighbors(i, neighbors2);
			} else {
				return "Bipartite: False";
			}
		}
		return "Bipartite: True\nPartition 1:\n" + partition1 + "\nPartition 2:\n" 
		+ partition2;
	};
	
	/**
	 * 
	 * @param vertex the vertex number
	 * @param neighbors an ArrayList of neighbors.
	 * @return true if the vertex is not a neighbor of the partition, 
	 * false if it is a neighbor.
	 */
	public boolean checkNoNeighbors(int vertex, ArrayList<Integer> neighbors){
		if(neighbors.contains(vertex)){
			return false;
		}
		return true;
	}
	
	/**
	 * Adds the given vertex to the neighbors list.
	 * @param vertex the given vertex.
	 * @param neighbors the neighbor list to which the vertex is added.
	 */
	public void addNeighbors(int vertex, ArrayList<Integer> neighbors){
		for(int i = 0; i < size; i++){
			if(array[vertex][i] == 1){
				neighbors.add(i); 
			}
		}
	}
	
	/**
	 * Prints the array.
	 */
	public void printArray(){
		String result = "";
		for(int i = 0; i < array.length; i++){
			for(int j = 0; j < array[i].length; j++){
				result += array[i][j];
				result +=" ";
			}
			result+="\n";
		}
		System.out.println(result);
	}
	
	public static void main(String[] args) {
		Graph graph = new Graph();
		System.out.println(graph.isBipartite());
	}
}
